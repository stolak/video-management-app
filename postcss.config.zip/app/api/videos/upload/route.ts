import { type NextRequest, NextResponse } from "next/server"
import { put } from "@vercel/blob"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get("file") as File
    const title = formData.get("title") as string
    const description = formData.get("description") as string

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 })
    }

    if (!title) {
      return NextResponse.json({ error: "Title is required" }, { status: 400 })
    }

    // Upload to Vercel Blob
    const blob = await put(file.name, file, {
      access: "public",
    })

    // In a real app, save metadata to database
    // const video = await db.insert(videosTable).values({
    //   title,
    //   description,
    //   filename: file.name,
    //   url: blob.url,
    //   size: file.size,
    //   uploadedAt: new Date(),
    // })

    console.log("Video uploaded:", {
      title,
      description,
      filename: file.name,
      url: blob.url,
      size: file.size,
    })

    return NextResponse.json({
      message: "Video uploaded successfully",
      url: blob.url,
    })
  } catch (error) {
    console.error("Upload error:", error)
    return NextResponse.json({ error: "Upload failed" }, { status: 500 })
  }
}
