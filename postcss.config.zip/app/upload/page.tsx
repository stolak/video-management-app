import VideoUpload from "@/components/video-upload"

export default function UploadPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-2xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Upload Video</h1>
          <p className="text-muted-foreground">Upload a new video to your collection</p>
        </div>

        <VideoUpload />
      </div>
    </div>
  )
}
