"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Video, Upload, LayoutDashboard } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function Navigation() {
  const pathname = usePathname()

  const navItems = [
    {
      href: "/",
      label: "Dashboard",
      icon: LayoutDashboard,
    },
    {
      href: "/upload",
      label: "Upload Video",
      icon: Upload,
    },
  ]

  return (
    <nav className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center space-x-2">
            <Video className="h-6 w-6" />
            <span className="font-bold text-xl">VideoManager</span>
          </div>

          <div className="flex items-center space-x-1">
            {navItems.map((item) => (
              <Button key={item.href} variant={pathname === item.href ? "default" : "ghost"} asChild>
                <Link href={item.href} className="flex items-center space-x-2">
                  <item.icon className="h-4 w-4" />
                  <span>{item.label}</span>
                </Link>
              </Button>
            ))}
          </div>
        </div>
      </div>
    </nav>
  )
}
